﻿using MailKit.Net.Smtp;
using Microsoft.Extensions.Configuration;
using MimeKit;
using MimeKit.Text;
using SendGrid;
using SendGrid.Helpers.Mail;
using System.Net.Mail;

namespace Auth.Services;

public class EmailService
{
    private const string AppName = "Auth";
    private const string From = "nekit_111@list.ru";
    public const string ConfirmSubject = "Link for confirm your account on app: Auth.";
    public const string PasswordResetSubject = "Link for password reset on app: Auth.";

    private const string Server = "smtp.mail.ru";
    private const int Port = 465;

    private const string UserName = "nekit_111@list.ru";
    private const string Password = "nzitJbeEXwdbJuc3zL5C";

    //public async Task SendAsync(string to, string subject, string body)
    //{
    //    var emailMessage = new MimeMessage();
    //    emailMessage.From.Add(new MailboxAddress(AppName, From));
    //    emailMessage.To.Add(new MailboxAddress(to, to));
    //    emailMessage.Subject = subject;
    //    emailMessage.Body = new TextPart(TextFormat.Html) { Text = body };

    //    using var client = new SmtpClient();
    //    await client.ConnectAsync(Server, Port, true);
    //    await client.AuthenticateAsync(UserName, Password);
    //    await client.SendAsync(emailMessage);

    //    await client.DisconnectAsync(true);
    //}

    private const string ApiKeySendGrid = "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";
    private const string Email = "clueless.tear.cloud@gmail.com";

    public async Task SendAsync(string to, string subject, string body)
    {
        var client = new SendGridClient(ApiKeySendGrid);
        var msg = new SendGridMessage()
        {
            From = new EmailAddress(Email, "Auth"),
            Subject = subject,
            PlainTextContent = body,
            HtmlContent = body,
        };
        msg.AddTo(to, to);

        var response = await client.SendEmailAsync(msg);
    }
}
