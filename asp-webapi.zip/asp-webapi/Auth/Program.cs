using Auth.Data;
using Auth.Services;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.Google;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using System.Security.Cryptography;
using System.Text;

//var q = new EmailService();

//await q.SendAsync("nekit_111@list.ru", "hello", "������");

//await Task.Delay(-1);


var builder = WebApplication.CreateBuilder(args);

//builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
//    .AddCookie(options =>
//    {
//        options.Cookie.HttpOnly = true;
//        options.Cookie.SecurePolicy = CookieSecurePolicy.Always;
//        options.Cookie.SameSite = SameSiteMode.None;

//        options.ExpireTimeSpan = TimeSpan.FromHours(20);
//        options.SlidingExpiration = true;

//        options.Cookie.Name = "hssesc";
//    });

#region auth providers

//builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
//    .AddJwtBearer(options =>
//    {
//        options.TokenValidationParameters = new TokenValidationParameters
//        {
//            ValidateIssuer = true,
//            ValidIssuer = "server",

//            ValidateAudience = true,
//            ValidAudience = "client",

//            ValidateLifetime = true,
//            ClockSkew = TimeSpan.Zero,

//            ValidateIssuerSigningKey = true,
//            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("qwertyuiopasdfghjklzxcvbnm123456")),
//        };
//    });

builder.Services.AddAuthentication(options =>
{
    options.DefaultScheme = CookieAuthenticationDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = GoogleDefaults.AuthenticationScheme;
})
    .AddCookie()
    .AddGoogle(GoogleDefaults.AuthenticationScheme, options =>
    {
        options.ClientId = "202510658632-as2b2jq4rldpnh3rnlo1t1cjt3thj3pl.apps.googleusercontent.com";
        options.ClientSecret = "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";
    });

#endregion

builder.Services.AddAuthorization();

var specific = "Specific";
builder.Services.AddCors(options =>
{
    options.AddPolicy(specific, policy => policy
    .WithOrigins("http://localhost:5173")
    .AllowAnyHeader()
    .AllowCredentials());
});

builder.Services.AddControllers();
builder.Services.AddDbContext<AuthDbContext>();


builder.Services.AddSingleton<EmailService>();
builder.Services.AddSingleton<TokenService>();
builder.Services.AddHostedService<TokenCleanupService>();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseCors(specific);

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.Run();
