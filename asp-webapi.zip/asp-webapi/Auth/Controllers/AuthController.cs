﻿using Microsoft.AspNetCore.Mvc;
using Auth.Data;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Text;
using Auth.Data.Entities;
using Microsoft.AspNetCore.Authentication.Google;
using System.Text.Json;

namespace Auth.Controllers;

[ApiController]
[Route("auth")]
public class AuthController(AuthDbContext dbContext) : ControllerBase
{
    private readonly AuthDbContext _dbContext = dbContext;

    #region JwtBearer

    //[AllowAnonymous] // JwtBearer
    //[HttpPost("SignIn")]
    //public async Task<ActionResult> SignIn(SignInUser signin)
    //{
    //    var user = await _dbContext.Users
    //        .Include(u => u.Roles)
    //        .FirstOrDefaultAsync(u => u.Login == signin.Login && u.Password == signin.Password);

    //    if (user is null)
    //        return NotFound("Пользователь не найден!");

    //    var claims = new List<Claim>
    //    {
    //        new(ClaimTypes.Sid, user.Id.ToString()),
    //        new(ClaimTypes.NameIdentifier, user.Login),
    //    };
    //    var claimsRoles = user.Roles.Select(x => new Claim(ClaimTypes.Role, x.Name));
    //    claims.AddRange(claimsRoles);

    //    var jwt = new JwtSecurityToken(
    //        issuer: "server",
    //        audience: "client",
    //        claims: claims,
    //        expires: DateTime.UtcNow.Add(TimeSpan.FromMinutes(20)),
    //        signingCredentials: new SigningCredentials(
    //            new SymmetricSecurityKey(Encoding.UTF8.GetBytes("qwertyuiopasdfghjklzxcvbnm123456")),
    //            SecurityAlgorithms.HmacSha256));

    //    return Ok(new JwtSecurityTokenHandler().WriteToken(jwt));
    //}

    #endregion

    #region Google

    //[AllowAnonymous]
    //[HttpGet("SignInGoogle")]
    //public async Task SignInGoogle()
    //{
    //    await HttpContext.ChallengeAsync(GoogleDefaults.AuthenticationScheme, new AuthenticationProperties
    //    {
    //        RedirectUri = Url.Action(nameof(GoogleResponse)),

    //    });

    //    //var properties = new AuthenticationProperties() { RedirectUri = Url.Action(nameof(GoogleResponse)) };
    //    //return Challenge(properties, GoogleDefaults.AuthenticationScheme);
    //}

    //[AllowAnonymous]
    //[HttpGet("GoogleResponse")]
    //public async Task<ActionResult> GoogleResponse()
    //{
    //    var authenticate = await HttpContext.AuthenticateAsync(CookieAuthenticationDefaults.AuthenticationScheme);
    //    if (authenticate.Succeeded == false ||
    //        authenticate.Principal == null)
    //        return BadRequest();

    //    var newGoogleUser = GoogleUser.CreateGoogleUserFromClaims(authenticate.Principal);

    //    var googleUser = await _dbContext.GoogleUsers.FindAsync(newGoogleUser.Id);
    //    if (googleUser == null)
    //    {
    //        _dbContext.GoogleUsers.Add(newGoogleUser);
    //        await _dbContext.SaveChangesAsync();
    //    }

    //    return Ok(JsonSerializer.Serialize(newGoogleUser));
    //}

    [AllowAnonymous] // Google
    [HttpPost("SignIn")]
    public async Task<ActionResult> SignIn(SignInGoogleUser signin)
    {
        var user = await _dbContext.GoogleUsers
            .FirstOrDefaultAsync(u => u.Email == signin.Email && u.Password == signin.Password);

        if (user is null)
            return NotFound("Пользователь не найден!");

        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, user.Id),
            new(ClaimTypes.Email, user.Email),
            new(ClaimTypes.GivenName, user.Name),
            new(ClaimTypes.Surname, user.Surname),
            new(ClaimTypes.Name, user.FullName),
        };

        var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
        var claimsPrincipal = new ClaimsPrincipal(claimsIdentity);

        await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, claimsPrincipal);
        return Ok();
    }

    #endregion

    [AllowAnonymous]
    [HttpPost("SignIn")]
    public async Task<ActionResult> SignIn(SignInUser signin)
    {
        var user = await _dbContext.Users
            .Include(u => u.Roles)
            .FirstOrDefaultAsync(u => u.Login == signin.Login && u.Password == signin.Password);

        if (user is null)
            return NotFound("Пользователь не найден!");

        var claims = new List<Claim>
          {
              new(ClaimTypes.Sid, user.Id.ToString()),
              new(ClaimTypes.NameIdentifier, user.Login),
          };
        var claimsRoles = user.Roles.Select(x => new Claim(ClaimTypes.Role, x.Name));
        claims.AddRange(claimsRoles);

        var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
        var claimsPrincipal = new ClaimsPrincipal(claimsIdentity);

        await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, claimsPrincipal);
        return Ok();
    }

    [Authorize]
    [HttpGet("SignOut")]
    public async Task<ActionResult> SignOutAuth()
    {
        await HttpContext.SignOutAsync();
        return Ok();
    }

}
