using Microsoft.AspNetCore.CookiePolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OutputCaching;
using Microsoft.AspNetCore.ResponseCompression;
using Microsoft.EntityFrameworkCore;
using NLog.Web;
using Serilog;
using Serilog.Events;
using System.Configuration;
using System.IO.Compression;
using System.Linq;
using Todo.Hubs;
using Todo.Middleware;
using Todo.Models;

//string ot = "{Timestamp:HH:mm:ss}:{SourceContext}{NewLine}{Message:lj}{NewLine}{Exception}";
//var logger = new LoggerConfiguration()
//    .MinimumLevel.Information()
//    .MinimumLevel.Override("Microsoft", LogEventLevel.Warning)
//    .MinimumLevel.Override("Microsoft.Hosting.Lifetime", LogEventLevel.Information);

//Log.Logger = logger
//    .WriteTo.Async(c => c.Console(outputTemplate: ot))
//    .WriteTo.Logger(l => l.Filter.ByIncludingOnly(evt => evt.Level == LogEventLevel.Information)
//            .WriteTo.Async(ou => ou.File("Logs/info-.txt", outputTemplate: ot, rollingInterval: RollingInterval.Day, rollOnFileSizeLimit: true)))
//    .WriteTo.Logger(l => l.Filter.ByIncludingOnly(evt => evt.Level == LogEventLevel.Warning)
//            .WriteTo.Async(ou => ou.File("Logs/warn-.txt", outputTemplate: ot, rollingInterval: RollingInterval.Day, rollOnFileSizeLimit: true)))
//    .WriteTo.Logger(l => l.Filter.ByIncludingOnly(evt => evt.Level == LogEventLevel.Error)
//            .WriteTo.Async(ou => ou.File("Logs/error-.txt", outputTemplate: ot, rollingInterval: RollingInterval.Day, rollOnFileSizeLimit: true)))
//    .WriteTo.Logger(l => l.Filter.ByIncludingOnly(evt => evt.Level == LogEventLevel.Fatal)
//            .WriteTo.Async(ou => ou.File("Logs/fatal-.txt", outputTemplate: ot, rollingInterval: RollingInterval.Day, rollOnFileSizeLimit: true)))
//    .CreateLogger();

var builder = WebApplication.CreateBuilder(args);
//builder.Logging.ClearProviders();
//builder.Services.AddSerilog();
//builder.Logging.AddLog4Net();
//builder.Host.UseNLog();

var allow = "Allow";
var specific = "Specific";

builder.Services.AddCors(options =>
{
    //options.AddDefaultPolicy(policy => policy
    //.Build());

    options.AddPolicy(allow, policy => policy
   .AllowAnyOrigin()
   .AllowAnyHeader()
   .AllowAnyMethod());

    options.AddPolicy(specific, policy => policy
    .WithOrigins("http://localhost:5173", "http://26.250.190.214:5173", "http://192.168.1.66:5173")
    .AllowAnyHeader()
    //.WithExposedHeaders("CustomHeader")
    //.WithMethods(["GET", "POST", "PATCH", "DELETE"])
    .AllowCredentials());
});

//app.UseCors(allow);
//app.UseCors(specific);

//[EnableCors(allow)] - [DisableCors]
//.RequireCors(allow)

//[ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
//[ResponseCache(Location = ResponseCacheLocation.Client, Duration = 300)]
//[ResponseCache(CacheProfileName = "Caching")]
//[ResponseCache(CacheProfileName = "NoCaching")]
builder.Services.AddControllers(options =>
{
    //options.CacheProfiles.Add("Caching",
    //    new CacheProfile()
    //    {
    //        Location = ResponseCacheLocation.Client,
    //        Duration = 300
    //    });
    //options.CacheProfiles.Add("NoCaching",
    //    new CacheProfile()
    //    {
    //        Location = ResponseCacheLocation.None,
    //        NoStore = true
    //    });
});
builder.Services.AddDbContext<TodoContext>(options => options.UseSqlServer(
    builder.Configuration.GetConnectionString("TodoContext")));

builder.Services.AddSignalR();

//builder.Services.AddDistributedMemoryCache();
//builder.Services.AddSession(options =>
//{
//    options.Cookie.HttpOnly = true;
//    options.Cookie.SecurePolicy = CookieSecurePolicy.Always;
//    options.Cookie.SameSite = SameSiteMode.None;
//    options.IdleTimeout = TimeSpan.FromMinutes(5);
//});

//swagger
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

//builder.Services.AddResponseCompression(options =>
//{
//    options.EnableForHttps = true;
//    options.Providers.Clear();
//    options.Providers.Add<GzipCompressionProvider>();
//    options.Providers.Add<BrotliCompressionProvider>();
//});

//builder.Services.Configure<GzipCompressionProviderOptions>(options =>
//{
//    options.Level = CompressionLevel.Fastest;
//});
//builder.Services.Configure<BrotliCompressionProviderOptions>(options =>
//{
//    options.Level = CompressionLevel.Fastest;
//});

//builder.Services.AddOutputCache(o =>
//{
//    o.SizeLimit = 64 * 1024 * 1024;
//    o.MaximumBodySize = 4 * 1024 * 1024;
//    o.DefaultExpirationTimeSpan = TimeSpan.FromMinutes(1);
//});

var app = builder.Build();
//app.UseResponseCompression();

//app.UseOutputCache();

//new WebApplicationOptions { WebRootPath = "wwwroot" }
//app.UseStaticFiles(new StaticFileOptions()
//{
//    OnPrepareResponse = ctx =>
//    {
//        ctx.Context.Response.Headers["Cache-Control"] = "public,max-age=600";
//    }
//});


if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors(specific);
app.UseHttpsRedirection();
//app.UseCustomMiddleware();

//app.UseAuthorization();
//app.UseSession();

//app.UseCookiePolicy(new CookiePolicyOptions()
//{
//    HttpOnly = HttpOnlyPolicy.Always,
//    Secure = CookieSecurePolicy.Always,
//    MinimumSameSitePolicy = SameSiteMode.None
//});

app.MapHub<SimpleChatHub>("/sch");
app.MapControllers();

app.Run();
