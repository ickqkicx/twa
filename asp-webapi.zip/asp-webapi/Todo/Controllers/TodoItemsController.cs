﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text.Json;
using System.Threading.Tasks;
using Humanizer;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis.Options;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Todo.Models;

namespace Todo.Controllers;

[ApiController]
[Route("api/todos")]
public class TodoItemsController : ControllerBase
{
    private readonly TodoContext _context;
    private readonly ILogger _logger;

    public TodoItemsController(TodoContext context, ILogger<TodoItemsController> logger)
    {
        _context = context;
        _logger = logger;
    }

    [HttpGet]
    public async Task<ActionResult<object>> GetTodoItems(int page = 1, int size = 10, [FromQuery] TodoItemFilter? filter = null)
    {
        var ftodos = _context.Todos.AsQueryable();
        if (filter?.Title?.Length >= 2) ftodos = ftodos.Where(x => x.Title.Contains(filter.Title));
        if (filter?.IsComplete != null) ftodos = ftodos.Where(x => x.IsComplete == filter.IsComplete);

        var count = await ftodos.CountAsync();

        var todos = await ftodos.Skip((page - 1) * size).Take(size).ToListAsync();
        //_logger.LogInformation(JsonSerializer.Serialize(todos));
        return new { count, todos };
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<TodoItem>> GetTodoItem(int id)
    {
        var todoItem = await _context.Todos.FindAsync(id);

        if (todoItem == null) return NotFound();
        return todoItem;
    }

    [HttpPost]
    public async Task<ActionResult<object>> PostTodoItem([FromBody] TodoItemCreate create)
    {
        var todoItem = create.TodoItem();
        _context.Todos.Add(todoItem);
        await _context.SaveChangesAsync();

        return CreatedAtAction(nameof(PostTodoItem), new { id = todoItem.Id });
    }

    [HttpPatch("{id}")]
    public async Task<IActionResult> PatchTodoItem(int id, [FromBody] TodoItemUpdate update)
    {
        var todoItem = await _context.Todos.FindAsync(id);
        if (todoItem == null) return NotFound();
        todoItem += update;

        _context.Entry(todoItem).State = EntityState.Modified;

        try
        {
            await _context.SaveChangesAsync();
        }
        catch (DbUpdateConcurrencyException)
        {
            if (_context.Todos.Any(e => e.Id == id) == false) return NotFound();
            throw;
        }

        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteTodoItem(int id)
    {
        var todoItem = await _context.Todos.FindAsync(id);
        if (todoItem == null) return NotFound();

        _context.Todos.Remove(todoItem);
        await _context.SaveChangesAsync();

        return NoContent();
    }

    [HttpGet("Speed")]
    public async Task<IActionResult> TestSpeed()
    {
        //var todos = new TodoItem[65536 * 16];
        var todos = new TodoItem[20];
        for (int i = 0; i < todos.Length; i++)
            todos[i] = new TodoItem() { Title = Guid.NewGuid().ToString().AsSpan(0, 20).ToString() };

        var q = Stopwatch.StartNew();
        await _context.Database.BeginTransactionAsync();

        _context.Todos.AddRange(todos);
        await _context.SaveChangesAsync();

        await _context.Database.CommitTransactionAsync();

        q.Stop();

        return Ok(q.Elapsed);
    }

}
