﻿using Microsoft.AspNetCore.SignalR;

namespace Todo.Hubs;
public record Message(string UserName, string Text, DateTime Time);

public class SimpleChatHub : Hub
{
    public async Task SendToGeneral(Message message)
    {
        await Clients.Others.SendAsync("ReceiveFromGeneral", message);
    }


    public async Task CallUser()
    {
        await Clients.Others.SendAsync("ReceiveCall", Context.UserIdentifier);
    }

    public async Task AnswerCall(bool accepted)
    {
        await Clients.Others.SendAsync("CallAnswered", accepted);
    }

    public async Task SendOffer(object offer)
    {
        await Clients.Others.SendAsync("ReceiveOffer", offer);
    }

    public async Task SendAnswer(object answer)
    {
        await Clients.Others.SendAsync("ReceiveAnswer", answer);
    }

    public async Task SendIceCandidate(object candidate)
    {
        await Clients.Others.SendAsync("ReceiveIceCandidate", candidate);
    }



    public async Task SendSignal(string signal)
    {
        await Clients.Others.SendAsync("ReceiveSignal", signal);
    }
}
