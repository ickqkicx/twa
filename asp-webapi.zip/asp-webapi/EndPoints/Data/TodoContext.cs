﻿using Microsoft.EntityFrameworkCore;
using EndPoints.Data.Entities;

namespace EndPoints.Data;

public class TodoContext(DbContextOptions<TodoContext> options) : DbContext(options)
{
    public DbSet<TodoItem> Todos { get; set; }

}
