using EndPoints.Data;
using EndPoints.EndPoints;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<TodoContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("TodoContext")));


var app = builder.Build();
app.MapGet("/", (HttpContext context) => context.Response.Redirect("/todos"));

app.MapTodosRoutes();

app.Run();
